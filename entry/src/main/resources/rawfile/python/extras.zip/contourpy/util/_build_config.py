# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.12",
        python_install_dir=r"/root/cp-prefix/lib/python3.12/site-packages/",
        python_path=r"/root/alpine-a64/run-python.sh",

        # Package versions
        contourpy_version="1.3.1",
        meson_version="1.10.1",
        mesonpy_version="0.22.1",
        pybind11_version="3.1.0",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/root/contourpy-1.3.1/builddir/lib/contourpy/util",
        source_dir=r"/root/contourpy-1.3.1/lib/contourpy/util",
        cross_build="True",

        # Build options
        build_options=r"-Dbuildtype=release -Dprefix=/root/cp-prefix --cross-file=/root/ohos-py-np/cross2.txt",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="False",
        b_ndebug="false",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="15.0.4",
        linker_id="ld.lld",
        compile_command="/opt/ohos-cmdline/command-line-tools/sdk/default/openharmony/native/llvm/bin/aarch64-unknown-linux-ohos-clang++",

        # Host machine
        host_cpu="aarch64",
        host_cpu_family="aarch64",
        host_cpu_endian="little",
        host_cpu_system="linux",

        # Build machine, same as host machine if not a cross_build
        build_cpu="x86_64",
        build_cpu_family="x86_64",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
